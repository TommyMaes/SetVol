SetVol 4.0	by TommyMaes
#################################################

DO NOT EXECUTE FILES AS ADMINISTRATOR !!!!!!!!!!!

#################################################
Install location C:\SetVol
#########################################################################

Installation


Execute installer.bat

There will be SetVolConfig and SetVolTest on the Desktop
You can put them anywhere you like

After installation open SetVolConfig.bat to configure the desired volume

Use the SetVolTest to manually activate the preset 

#########################################################################

For Advanced user

In the C:\SetVol\Source folder you can set options for mute/unmute inside 
the SetVol.txt which containz a powershell script in plain text
Look at the bottom of that file for more info

#########################################################################

Uninstall

In C:\Setvol\Source

Execute uninstall.bat

You may want to remove the empty folder C:\SetVol manually

#########################################################################
