  ##############################################################
  SetVol 4.2 by TommyMaes
  ##############################################################
  -------------DO NOT OPEN FILES AS ADMINISTRATOR --------------
  ##############################################################
  --------------------------------------------------------------
  -------------------------- Manual ----------------------------
  --------------------------------------------------------------
  Use Installer for installation
  
  On the desktop there will be SetVolConfig and SetVolTest
  Delete them if you want
 
  Install location: C:\SetVol
 
  Use SetVolConfig to configure the desired volume
 
  Use SetVolTest to manually activate the preset 
 
  Use DisableStartup to disable on startup
 
  Use FixStartup to enable on startup

  Use Uninstaller to uninstall SetVol  
  
#########################################################################

For Advanced user

In the C:\SetVol\Source folder you can set options for mute/unmute inside 
the SetVol.txt which containz a powershell script in plain text
Look at the bottom of that file for more info

#########################################################################

For the latest version visit https://github.com/TommyMaes/SetVol

