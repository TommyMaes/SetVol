  ##############################################################
  SetVol 5.1 by TommyMaes
  ##############################################################
  ------------- DO NOT OPEN FILES AS ADMINISTRATOR -------------
  ##############################################################
  --------------------------------------------------------------
  -------------------------- Manual ----------------------------
  --------------------------------------------------------------
  - Unpack before installing

  - Use Installer for installation
  
  Install location: C:\SetVol
  
  On the desktop there will be SetVol and SetVolTest
  Delete them if you want, they are also located in C:\SetVol
  
  - Use SetVolTest to manually activate the preset 
  
  - Use SetVol to:
 
  Configure the desired volume
  
  Test the volume
 
  Disable on startup
 
  Enable on startup

  Uninstall SetVol  
  
  ##############################################################

 For the latest version visit https://github.com/TommyMaes/SetVol

  ##############################################################



