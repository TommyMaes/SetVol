SetVol 4.2 	by TommyMaes
#################################################

DO NOT EXECUTE FILES AS ADMINISTRATOR !!!!!!!!!!!

#################################################
Install location C:\SetVol
#########################################################################

Installation

Open the Installer

Afte Installation SetVolConfig and SetVolTest are on the Desktop
You can delete them if you want

#########################################################################

Open SetVolConfig to configure the volume

Use the SetVolTest to manually activate the preset 

#########################################################################

For Advanced user

In the C:\SetVol\Source folder you can set options for mute/unmute inside 
the SetVol.txt which containz a powershell script in plain text
Look at the bottom of that file for more info

#########################################################################

Uninstall

In C:\Setvol\Source open the Uninstaller

#########################################################################
